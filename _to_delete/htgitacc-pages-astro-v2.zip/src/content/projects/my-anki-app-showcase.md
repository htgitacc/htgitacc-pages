---
title_hu: "My-Anki — Kontextusérzékeny szókincstanulás"
title_en: "My-Anki — Context-aware vocabulary learning"
summary_hu: >
  Angol–magyar szókincstanuló app, amely a klasszikus ANKI
  kártyarendszert AI-alapú kontextus-felismeréssel bővíti: a beírt
  mondat alapján a szó adott jelentését, magyar fordítását és két
  további példamondatot generál.
summary_en: >
  An English–Hungarian vocabulary app that extends the classic ANKI
  flashcard system with AI context-awareness: given a sentence, it
  generates the word's meaning in that specific context, its Hungarian
  translation, and two more example sentences.
tech: ["SvelteKit 5", "Tailwind CSS v4", "Supabase", "Gemini API"]
repoUrls: ["https://github.com/htgitacc/my-anki-app-showcase"]
demoUrl: "https://my-anki-app-pi.vercel.app"
pdfUrls: []
image: null
# A repóban feltöltött screenshotok elérési útját még nem tudtam
# megbízhatóan azonosíteni — add meg, és ide bekerül (l. README).
featured: true
wip: true
order: 40
---
